import TrashIcon from "./Trash"
import PencilIcon from "./Pencil"

export { TrashIcon, PencilIcon }
